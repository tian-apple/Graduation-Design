Cipher module
=============

.. automodule:: Cipher
   :members:
   :undoc-members:
   :show-inheritance:
